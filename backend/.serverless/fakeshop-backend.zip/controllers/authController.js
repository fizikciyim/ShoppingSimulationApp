import db from "../config/db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = "supersecretkey";

// ?? Kullan�c� kay�t i�lemi
export const register = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Kullan�c� zaten var m�?
    const [existing] = await db.query("SELECT * FROM users WHERE username = ?", [
      username,
    ]);

    if (existing.length > 0)
      return res.status(400).json({ message: "Kullan�c� ad� zaten mevcut." });

    // �ifreyi hashle
    const hashed = await bcrypt.hash(password, 10);

    // Yeni kullan�c�y� kaydet
    await db.query("INSERT INTO users (username, password) VALUES (?, ?)", [
      username,
      hashed,
    ]);

    res.json({ message: "Kay�t ba�ar�l�." });
  } catch (err) {
    console.error("Kay�t hatas�:", err);
    res.status(500).json({ message: "Sunucu hatas�." });
  }
};

// ?? Kullan�c� giri� i�lemi
export const login = async (req, res) => {
  try {
    const { username, password } = req.body;

    const [rows] = await db.query("SELECT * FROM users WHERE username = ?", [
      username,
    ]);

    if (rows.length === 0)
      return res.status(400).json({ message: "Kullan�c� bulunamad�." });

    const user = rows[0];

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ message: "�ifre yanl��." });

    const token = jwt.sign(
      { id: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      message: "Giri� ba�ar�l�.",
      token,
      user: {
        id: user.id,
        username: user.username,
      },
    });
  } catch (err) {
    console.error("Giri� hatas�:", err);
    res.status(500).json({ message: "Sunucu hatas�." });
  }
};

// ?? �ifre de�i�tirme i�lemi
export const changePassword = async (req, res) => {
  try {
    const userId = req.user.id; // verifyToken middleware'inden geliyor
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword)
      return res.status(400).json({ message: "T�m alanlar zorunludur." });

    // Kullan�c�n�n mevcut �ifresini al
    const [rows] = await db.query("SELECT password FROM users WHERE id = ?", [
      userId,
    ]);

    if (!rows.length)
      return res.status(404).json({ message: "Kullan�c� bulunamad�." });

    const user = rows[0];

    // Eski �ifre do�ru mu kontrol et
    const isMatch = await bcrypt.compare(oldPassword, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Mevcut �ifre yanl��." });

    // Yeni �ifreyi hashle ve g�ncelle
    const hashed = await bcrypt.hash(newPassword, 10);
    await db.query("UPDATE users SET password = ? WHERE id = ?", [
      hashed,
      userId,
    ]);

    res.json({ message: "�ifre ba�ar�yla de�i�tirildi." });
  } catch (err) {
    console.error("�ifre de�i�tirme hatas�:", err);
    res.status(500).json({ message: "Sunucu hatas�." });
  }
};
