import db from "../config/db.js";

// ? Yeni adres ekleme
export const addAddress = async (req, res) => {
  try {
    const userId = req.user.id;
    const { title, phone, city, district, street, building_no, apartment_no } =
      req.body;

    if (!title || !city || !district || !street) {
      return res
        .status(400)
        .json({ message: "Eksik bilgi. Zorunlu alanlar� doldurun." });
    }

    // ? E�er kullan�c�n�n hi� adresi yoksa, ilk adres ana adres olur
    const [existing] = await db.query(
      "SELECT COUNT(*) AS count FROM addresses WHERE user_id = ?",
      [userId]
    );
    const isMain = existing[0].count === 0 ? 1 : 0;

    await db.query(
      `INSERT INTO addresses 
       (user_id, title, phone, city, district, street, building_no, apartment_no, is_main)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId,
        title,
        phone,
        city,
        district,
        street,
        building_no,
        apartment_no,
        isMain,
      ]
    );

    res.json({
      success: true,
      message: "Adres ba�ar�yla eklendi.",
      is_main: isMain,
    });
  } catch (error) {
    console.error("Adres ekleme hatas�:", error);
    res.status(500).json({
      success: false,
      message: "Adres eklenirken bir hata olu�tu.",
    });
  }
};

// ? Kullan�c�n�n adreslerini getir
export const getAddresses = async (req, res) => {
  try {
    const userId = req.user.id;
    const [rows] = await db.query(
      "SELECT * FROM addresses WHERE user_id = ? ORDER BY created_at DESC",
      [userId]
    );
    res.json(rows);
  } catch (error) {
    console.error("Adres listeleme hatas�:", error);
    res.status(500).json({ message: "Adresler al�n�rken hata olu�tu." });
  }
};

// ? Adres silme
export const deleteAddress = async (req, res) => {
  try {
    const userId = req.user.id;
    const id = req.params.id;

    const [rows] = await db.query(
      "SELECT * FROM addresses WHERE id = ? AND user_id = ?",
      [id, userId]
    );

    if (!rows.length) {
      return res
        .status(404)
        .json({ message: "Adres bulunamad� veya yetkiniz yok." });
    }

    await db.query("DELETE FROM addresses WHERE id = ? AND user_id = ?", [
      id,
      userId,
    ]);

    res.json({ success: true, message: "Adres ba�ar�yla silindi." });
  } catch (error) {
    console.error("Adres silme hatas�:", error);
    res.status(500).json({
      success: false,
      message: "Adres silinirken hata olu�tu.",
    });
  }
};

// ? Adres g�ncelleme
export const updateAddress = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const { title, phone, city, district, street, building_no, apartment_no } =
      req.body;

    const [rows] = await db.query(
      "SELECT * FROM addresses WHERE id = ? AND user_id = ?",
      [id, userId]
    );

    if (!rows.length) {
      return res
        .status(404)
        .json({ success: false, message: "Adres bulunamad� veya eri�im yok." });
    }

    await db.query(
      `UPDATE addresses
       SET title = ?, phone = ?, city = ?, district = ?, street = ?, building_no = ?, apartment_no = ?
       WHERE id = ? AND user_id = ?`,
      [
        title,
        phone,
        city,
        district,
        street,
        building_no,
        apartment_no,
        id,
        userId,
      ]
    );

    res.json({ success: true, message: "Adres ba�ar�yla g�ncellendi." });
  } catch (error) {
    console.error("Adres g�ncelleme hatas�:", error);
    res.status(500).json({
      success: false,
      message: "Adres g�ncellenirken hata olu�tu.",
    });
  }
};

// ? Ana adres belirleme
export const setMainAddress = async (req, res) => {
  try {
    const userId = req.user.id;
    const addressId = req.params.id;

    // 1?? Ayn� kullan�c�ya ait t�m adresleri s�f�rla
    await db.query("UPDATE addresses SET is_main = 0 WHERE user_id = ?", [
      userId,
    ]);

    // 2?? Se�ilen adresi ana yap
    const [result] = await db.query(
      "UPDATE addresses SET is_main = 1 WHERE id = ? AND user_id = ?",
      [addressId, userId]
    );

    if (result.affectedRows === 0) {
      return res
        .status(404)
        .json({ message: "Adres bulunamad� veya eri�im yok." });
    }

    res.json({ success: true, message: "Ana adres ba�ar�yla g�ncellendi." });
  } catch (error) {
    console.error("Ana adres hatas�:", error);
    res.status(500).json({
      success: false,
      message: "Ana adres g�ncellenirken hata olu�tu.",
    });
  }
};
