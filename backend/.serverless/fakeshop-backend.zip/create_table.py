import mysql.connector

# MySQL bağlantısını oluştur
connection = mysql.connector.connect(
    host="localhost",       # Sunucu adresi (genelde localhost)
    user="root",            # MySQL kullanıcı adı
    password="123456",     # MySQL parolan
    database="fakeshop"  # Hedef veritabanı
)

cursor = connection.cursor()

# cursor.execute("""
#  CREATE TABLE feedbacks (
#   id INT AUTO_INCREMENT PRIMARY KEY,
#   user_id INT NULL,
#   category VARCHAR(100) NOT NULL,
#   message TEXT NOT NULL,
#   email VARCHAR(255) NULL,
#   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#   FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
# )
# """)

cursor.execute("""
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(10) NOT NULL UNIQUE,        -- 10 karakterlik benzersiz sipariş numarası (örnek: ORD5F2A9B)
  user_id INT NOT NULL,
  address_id INT NOT NULL,
  items JSON NOT NULL,                             -- Ürün listesi [{id,name,qty,price}]
  total_price DECIMAL(10,2) NOT NULL,
  payment_method ENUM('Kredi Kartı','Kapıda Ödeme','EFT/Havale') NOT NULL,
  order_note VARCHAR(255),                         -- Kullanıcının isteğe bağlı notu
  status ENUM('Hazırlanıyor','Kargoya Verildi','Teslimatta','Teslim Edildi','İptal Edildi') DEFAULT 'Hazırlanıyor',
  has_event BOOLEAN DEFAULT FALSE,                 -- İptal olayı yaşandı mı?
  event_text VARCHAR(255),                         -- İptal nedeni ("Kargo kayboldu", "Ürün kırıldı" vs.)
  event_index INT DEFAULT NULL,                    -- Olay hangi aşamada oldu (örnek: 1 = Kargoda)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (address_id) REFERENCES addresses(id) ON DELETE CASCADE
)
""")

# Değişiklikleri kaydet
connection.commit()

print("✅ 'addresses' tablosu başarıyla oluşturuldu!")

# Bağlantıyı kapat
cursor.close()
connection.close()
