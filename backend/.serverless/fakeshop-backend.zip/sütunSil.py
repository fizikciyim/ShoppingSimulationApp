import mysql.connector

# MySQL'e bağlan
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="fakeshop"
)

cursor = conn.cursor()

# email sütununu sil
cursor.execute("ALTER TABLE users DROP COLUMN email")

print("email sütunu silindi ✅")

# Bağlantıyı kapat
cursor.close()
conn.close()
