import mysql.connector

# 1. MySQL'e bağlan
conn = mysql.connector.connect(
    host="localhost",
    user="root",       # kendi MySQL kullanıcı adın
    password="123456"        # şifre (boşsa bırak)
)

cursor = conn.cursor()

# 2. Veritabanını oluştur
cursor.execute("CREATE DATABASE IF NOT EXISTS fakeshop")
cursor.execute("USE fakeshop")

# 3. Users tablosunu oluştur
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  balance DECIMAL(10,2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)
""")

print("Veritabanı ve tablo oluşturuldu ✅")

# Bağlantıyı kapat
cursor.close()
conn.close()
